$(function () {
  $("#shellinaboxframe").attr('src', 'https://'+document.domain+':'+shellinaboxport);
});
