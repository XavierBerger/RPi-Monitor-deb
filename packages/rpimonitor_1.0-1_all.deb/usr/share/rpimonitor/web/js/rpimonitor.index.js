$(function () {
  setupqr();
  doqr(document.URL);
});
