$(function () {
  ShowFriends();
  /* Add qrcode shortcut*/
  setupqr();
  doqr(document.URL);
});
