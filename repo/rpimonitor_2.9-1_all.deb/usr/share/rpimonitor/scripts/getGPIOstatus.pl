#!/usr/bin/perl
use strict;

print <<EOF;
<style>
table {
 border-collapse:collapse;
 width:90%;
 }
th, td {
 border:1px solid black;
 }
td {
 text-align:center;
 }
caption {
 font-weight:bold
 }
</style> 
EOF

print "<table align='center'>\n";
open(FILE,"gpio readall|") or die "$!\n";
while (<FILE>) {
  chomp;
  /Model/ and s/[-|+]//g and print "<th colspan=12>$_</th>\n" and next;
  /^ \+/ and print "<tr><td colspan=12></td></tr>" and next;
  s/^ \|/<tr align='center'><td>/;
  s/\| Physical \|/<\/td><td colspan='2'> Physical <\/td><td>/;
  s/\|$/<\/td><\/tr>/;
  s/\|\|/<\/td><td>/g;
  s/\|/<\/td><td>/g;
  print "$_\n";
}
close(FILE);
print "</table>\n";
