$(function () {
  setupqr();
  doqr(document.URL);
  ShowFriends();
});
