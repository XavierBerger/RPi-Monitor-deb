#!/bin/bash
sudo aptitude -y install librrds-perl libhttp-daemon-perl libjson-perl libipc-sharelite-perl libfile-which-perl shellinabox
sudo dpkg -i rpimonitor_2.6-1_all.deb
sudo apt-get update && sudo service rpimonitor update
