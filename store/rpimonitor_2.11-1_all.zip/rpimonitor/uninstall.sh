#!/bin/bash
sudo apt-get -y purge rpimonitor
